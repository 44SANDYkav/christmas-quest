# The Family Christmas Quest - simple free website

This version has no Firebase, no paid cloud account and no database.

## What the family gets
- One permanent website link to bookmark or save to the phone home screen
- Today's trivia question
- Google Form buttons for trivia and private Catchphrase guesses
- The same shared Catchphrase reveal
- Leaderboard and Peak winners

## What you update each day
Open `game-data.js` in any text editor. Change:
- `day`
- `question`
- `clueCount`
- `dailyWinner` and `dailyAnswer`
- leaderboard points
- Peak winner when somebody solves it

Save and upload/commit the file. The permanent family URL does not change. Everyone refreshes the page to see the update.

## Free hosting option: GitHub Pages
1. Create a free GitHub account and a new public repository called `christmas-quest`.
2. Upload every file and the `assets` folder from this package.
3. Open repository Settings > Pages.
4. Under Build and deployment choose `Deploy from a branch`.
5. Choose `main` and `/root`, then Save.
6. GitHub gives you a permanent address similar to `https://your-name.github.io/christmas-quest/`.
7. Send that single address to the family in WhatsApp.

## Google Forms
Create two Google Forms:
1. Daily Trivia: Name + Answer
2. Catchphrase Guess: Name + Peak + Guess

In each Google Form:
- Open Responses > Link to Sheets
- Copy the responder link
- Paste the links into `game-data.js`

Google Forms records submission timestamps. Use the linked Google Sheet to identify the first correct trivia answer and the first correct Catchphrase guess.

## Add your pictures
Replace these files with real 1600 x 900 JPG images:
- `assets/peak1.jpg`
- `assets/peak2.jpg`
- `assets/peak3.jpg`

When moving to a new Peak, change the `picture` value in `game-data.js`.

## Recommended daily routine
1. At the scheduled time, update `question` and `day`.
2. Post the permanent website link in WhatsApp.
3. Check the Google Sheet for the first correct answer.
4. Update `dailyWinner`, `dailyAnswer`, `clueCount` and leaderboard.
5. Save/upload `game-data.js`.
6. Post in WhatsApp: "Correct - refresh the Quest page for today's reveal."

Typical daily administration time: 2-4 minutes.
